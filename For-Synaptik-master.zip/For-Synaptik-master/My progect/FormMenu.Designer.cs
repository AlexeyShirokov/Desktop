﻿namespace My_progect
{
    partial class FormMenu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.buttonSoups = new System.Windows.Forms.Button();
            this.buttonSecond = new System.Windows.Forms.Button();
            this.buttonSalads = new System.Windows.Forms.Button();
            this.buttonDrinks = new System.Windows.Forms.Button();
            this.buttonOrder = new System.Windows.Forms.Button();
            this.buttonWorker = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSoups
            // 
            this.buttonSoups.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonSoups.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSoups.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSoups.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSoups.Location = new System.Drawing.Point(28, 94);
            this.buttonSoups.Name = "buttonSoups";
            this.buttonSoups.Size = new System.Drawing.Size(240, 50);
            this.buttonSoups.TabIndex = 0;
            this.buttonSoups.Text = "Первое блюдо";
            this.buttonSoups.UseVisualStyleBackColor = false;
            this.buttonSoups.Click += new System.EventHandler(this.buttonSoups_Click);
            // 
            // buttonSecond
            // 
            this.buttonSecond.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonSecond.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSecond.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSecond.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSecond.Location = new System.Drawing.Point(28, 149);
            this.buttonSecond.Name = "buttonSecond";
            this.buttonSecond.Size = new System.Drawing.Size(240, 50);
            this.buttonSecond.TabIndex = 1;
            this.buttonSecond.Text = "Горячее блюдо";
            this.buttonSecond.UseVisualStyleBackColor = false;
            this.buttonSecond.Click += new System.EventHandler(this.buttonSecond_Click);
            // 
            // buttonSalads
            // 
            this.buttonSalads.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonSalads.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSalads.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSalads.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSalads.Location = new System.Drawing.Point(28, 203);
            this.buttonSalads.Name = "buttonSalads";
            this.buttonSalads.Size = new System.Drawing.Size(240, 50);
            this.buttonSalads.TabIndex = 2;
            this.buttonSalads.Text = "Салаты";
            this.buttonSalads.UseVisualStyleBackColor = false;
            this.buttonSalads.Click += new System.EventHandler(this.buttonSalads_Click);
            // 
            // buttonDrinks
            // 
            this.buttonDrinks.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonDrinks.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrinks.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDrinks.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDrinks.Location = new System.Drawing.Point(28, 258);
            this.buttonDrinks.Name = "buttonDrinks";
            this.buttonDrinks.Size = new System.Drawing.Size(240, 50);
            this.buttonDrinks.TabIndex = 3;
            this.buttonDrinks.Text = "Напитки";
            this.buttonDrinks.UseVisualStyleBackColor = false;
            this.buttonDrinks.Click += new System.EventHandler(this.buttonDrinks_Click);
            // 
            // buttonOrder
            // 
            this.buttonOrder.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonOrder.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonOrder.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonOrder.Location = new System.Drawing.Point(28, 378);
            this.buttonOrder.Name = "buttonOrder";
            this.buttonOrder.Size = new System.Drawing.Size(240, 50);
            this.buttonOrder.TabIndex = 4;
            this.buttonOrder.Text = "Оформить заказ";
            this.buttonOrder.UseVisualStyleBackColor = false;
            this.buttonOrder.Click += new System.EventHandler(this.buttonOrder_Click);
            // 
            // buttonWorker
            // 
            this.buttonWorker.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonWorker.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonWorker.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonWorker.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonWorker.Location = new System.Drawing.Point(28, 313);
            this.buttonWorker.Name = "buttonWorker";
            this.buttonWorker.Size = new System.Drawing.Size(240, 50);
            this.buttonWorker.TabIndex = 5;
            this.buttonWorker.Text = "Сотрудник";
            this.buttonWorker.UseVisualStyleBackColor = false;
            this.buttonWorker.Click += new System.EventHandler(this.buttonWorker_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonEdit.Location = new System.Drawing.Point(3, 433);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(15, 16);
            this.buttonEdit.TabIndex = 7;
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox.Image")));
            this.pictureBox.Location = new System.Drawing.Point(12, 12);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(276, 76);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 22;
            this.pictureBox.TabStop = false;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(300, 452);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonWorker);
            this.Controls.Add(this.buttonOrder);
            this.Controls.Add(this.buttonDrinks);
            this.Controls.Add(this.buttonSalads);
            this.Controls.Add(this.buttonSecond);
            this.Controls.Add(this.buttonSoups);
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSoups;
        private System.Windows.Forms.Button buttonSecond;
        private System.Windows.Forms.Button buttonSalads;
        private System.Windows.Forms.Button buttonDrinks;
        private System.Windows.Forms.Button buttonOrder;
        private System.Windows.Forms.Button buttonWorker;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.PictureBox pictureBox;
    }
}

